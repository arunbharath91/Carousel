import '../style.scss';
import './carousel-config';
