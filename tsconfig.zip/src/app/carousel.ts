import { _s } from "./helper";

interface IOptions {
interval?: number;
autoplay?: boolean;
nav?: boolean;
dots?: boolean;
gap?: number;
responsive? : IResponsive[];
}

interface IResponsive {
  [breakPoint: number]: {items: number, nav: boolean}
}

const defaultOptions: IOptions = {
interval: 0,
autoplay: false,
nav: true,
dots: true,
gap: 30,
responsive:[
 {0: {items:1, nav: true}}, //if width greater than 0 (1 item will show)
 {600: {items:2, nav: true}}, //if width greater than 600 (2  item will show)
 {1000:{items:4, nav: true}} //if width greater than 1000 (4 item will show)
]
}

export class Carousel {
  private selector!: HTMLElement;
  private carouselContainer!: HTMLElement;
  private carouselItems!: HTMLElement[];
  private containerWidth!: number;
  private totalItems!: number;
  private jumpSlideWidth!: number;
  private options!: IOptions;
  private items!: number;
constructor(selector: string, options: IOptions) {
this.config(selector, options);
}


 protected config(selector: string, options: IOptions) {
  this.options = {...defaultOptions, ...options}
  this.selector = (document.querySelector(selector) as HTMLElement);
  this.carouselContainer = (document.querySelector(".carousel-container") as HTMLElement);
  this.carouselItems = Array.prototype.slice.call(this.carouselContainer.children);
  this.containerWidth = this.carouselContainer.offsetWidth;
  this.totalItems = 0;
  this.jumpSlideWidth = 0;
  this.items = 0;
  this.load();
}

protected load() {
  for (let brPtI in defaultOptions.responsive) {
    const breakPoint = Object.keys(defaultOptions.responsive[brPtI as any]);
    if (window.innerWidth > Number(breakPoint[0])) {
      this.items = (Object.values(defaultOptions.responsive[brPtI as any])[0] as any).items
    }
  }
  this.initSlider();
}

protected initSlider() {
 let totalItemsWidth:number = 0;
 Array.from(this.carouselItems).forEach((carousel) => {
   (carousel as HTMLElement).style.width = `${(this.carouselContainer.offsetWidth / this.items) - Number(this.options.gap)}px`;
   (carousel as HTMLElement).style.margin =`${(Number(this.options.gap)/2)}px`;
   totalItemsWidth += this.carouselContainer.offsetWidth/this.items + Number(this.options.gap);
   this.totalItems++;
 });
 this.carouselContainer.style.width = `${totalItemsWidth}px`;
 this.projectControls();
}

  projectControls() {
  if(this.options.nav) this.generateNav();
  if(this.options.dots) this.generateLi();
  }

  generateNav() {
    const presence = document.querySelector("slider-nav.sliderNav");
      if (presence) {
        presence.remove();
      }
    const slideNav = document.createElement('slider-nav');
    slideNav.className = 'sliderNav'
    slideNav.style.zIndex = '1000';
    slideNav.setAttribute('data-current', '1');
    slideNav.innerHTML = `<a class="control_prev">	&#8592; </a>
    <a class="control_next">&#8594; </a>`;
    this.selector.appendChild(slideNav);
    const allSlides = Math.ceil(this.totalItems / this.items) -1;

    const prev = (slideNav.querySelector('a.control_prev') as HTMLElement);
    const next = (slideNav.querySelector('a.control_next') as HTMLElement);
    let current = Number(slideNav.getAttribute('data-current'));
    prev.addEventListener('click', () => {
    if(current <= allSlides){
      current = current+1;
    } else {
      current = 1;
    }
    slideNav.setAttribute('data-current', current.toString());
    });

    next.addEventListener('click', () => {
    if(current <= allSlides){
      current = current+1;
    } else {
      current = 0;
    }
    slideNav.setAttribute('data-current', current.toString());
    this.jumpSlideWidth = this.jumpSlideWidth + (this.containerWidth * current);
    console.log(this.containerWidth)
    this.carouselContainer.style.marginLeft = - this.jumpSlideWidth + "px";
    });

  }

protected generateLi() {
  const presence = document.querySelector("ul.sliderCtrl");
    if (presence) {
      presence.remove();
    }
    const allSlides = Math.ceil(this.totalItems / this.items);
    const ul = document.createElement("ul");
    ul.className = 'sliderCtrl';
    for (let i = 1; i <= allSlides; i++) {
      const li = document.createElement("li");
      li.id = i.toString();
      li.innerHTML = i.toString();
      li.addEventListener("click", (e) => { this.controlSlides(e.target) });
      ul.appendChild(li);
      if (i == 1) {
        li.className = "active";
      }
    }
    this.selector.appendChild(ul);
  }

protected controlSlides(ele: any) {
    const prevActive = _s(`ul.sliderCtrl li`).hasClass('active').attr('id');
    _s(ele).addClass('active').siblings().removeClass('active');
    const numb = (ele.id - 1) - Number(prevActive) + 1
    this.jumpSlideWidth = this.jumpSlideWidth + (this.containerWidth * numb);
    console.log(this.jumpSlideWidth)
    this.carouselContainer.style.marginLeft = - this.jumpSlideWidth + "px";
  }

}
