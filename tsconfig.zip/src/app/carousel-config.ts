import  "./carousel";
import { Carousel } from "./carousel";

(window as any).onload = new Carousel('#carousel', {interval: 1000});
(window as any).addEventListener('resize', () => {
  (window as any).onload = new Carousel('#carousel', {interval: 1000});
});
